Version 0.9 - 3 April 2019

Hello, and thank you for downloading the Rock Band 4 Tier Maker!

This was made by request, and should be mostly (if not, fully) functional.
Make sure you keep the Sys folder and its contents intact, otherwise the program will not work properly.
Also, if you export/save too many times in one session, the program will crash due to a bug in Windows Forms'
DrawString method.
Aside from that, you should be free to do whatever you want.

Source code can be found here: https://github.com/pdnelson/Rock-Band-4-Tier-Maker

You're welcome to report any bugs/errors to me at supermariokart98@gmail.com.


Thanks for reading this, and enjoy the program!

-Patrick